export default{
    position_placeholder : '[placeholder="position"]',
    company_placeholder : '[placeholder="company"]',
    location_placeholder : '[placeholder="location"]'
}